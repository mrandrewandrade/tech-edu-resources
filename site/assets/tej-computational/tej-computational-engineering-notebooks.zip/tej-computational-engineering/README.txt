Open the eleven notebooks in order or use the notebook matched to the current electronics lesson.
Upload data/circuit-measurements.csv beside Notebook 5. Notebook 7 works without physical hardware.
For local JupyterLab, create a virtual environment and install requirements-jupyter.txt.
Browser storage is not a backup: download work after every JupyterLite session.
